
//This note is exclusively for java trainees



a) Please execute tablescripts available inside the resources package
b)update the Database credentials(UserName,Password) in application.properties file of the Backend Spring boot project.
Execute the SpringBoot Application(BookSpringBootApplication) as Java application

a) to Make request to the Post Web service use the below URL:
http://localhost:3000/userAPI/login.
b)To Make request to the Get Web service use the below URL:
http://localhost:3000/booksAPI/books



